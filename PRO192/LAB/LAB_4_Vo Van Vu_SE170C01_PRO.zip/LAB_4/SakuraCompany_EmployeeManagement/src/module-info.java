/**
 * 
 */
/**
 * @author vuvo0
 *
 */
module SakuraCompany_EmployeeManagement {
	requires java.desktop;
}