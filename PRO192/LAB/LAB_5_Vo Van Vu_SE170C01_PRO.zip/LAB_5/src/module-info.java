/**
 * 
 */
/**
 * @author vuvo0
 *
 */
module LAB_5 {
}