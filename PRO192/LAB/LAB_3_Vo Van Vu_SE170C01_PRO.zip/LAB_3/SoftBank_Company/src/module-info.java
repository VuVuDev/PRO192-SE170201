/**
 * 
 */
/**
 * @author vuvo0
 *
 */
module SoftBank_Company {
}